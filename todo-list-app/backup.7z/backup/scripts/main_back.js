// Enable the enter key to submit a new item from the input field
var inputField = document.getElementById("list-entry");

inputField.addEventListener("keyup", function (event) {
  if (event.keyCode === 13) {
    event.preventDefault();
    document.getElementById("add-btn").click();
  }
});

// Create a new item for the list
document.getElementById("add-btn").addEventListener("click", function () {

  var textInput = document.getElementById("list-entry").value;
  var node = document.createElement("LI");
  node.setAttribute("id", "list-item");
  node.setAttribute("class", "default-cursor");
  node.setAttribute("style", "text-decoration: none;");
  var textNode = document.createTextNode(textInput);
  node.appendChild(textNode);

  // Add item to list if input field is not blank
  if (textInput === "") {
    alert("Please enter some text to create a new item");
  } else {
    document.getElementById("list").appendChild(node);
  }
  document.getElementById("list-entry").value = "";

  // Append a remove button to each li element
  var span = document.createElement("BUTTON");
  span.setAttribute("id", "appendedBtn");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  node.appendChild(span);

  // Event listener to remove the li element
  span.addEventListener(
    "click",
    function () {
      node.parentNode.removeChild(node);
    },
    false
  );
});

// Scroll-to-top button
window.onscroll = function () {
  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
    document.getElementById("scroll-to-top").style.display = "block";
  } else {
    document.getElementById("scroll-to-top").style.display = "none";
  }
};

window.onload = function () {
  document
    .getElementById("scroll-to-top")
    .addEventListener("click", function () {
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    });
};

// Saving to localStorage
var returnList = document.querySelector("ul");
//var getList = document.getElementById("list");

window.onbeforeunload = function () {
  localStorage.setItem("recallListItems", returnList.innerHTML);
};

var saved = localStorage.getItem("recallListItems");

if (saved) {
  returnList.innerHTML = saved;
}

// Clear button
document.getElementById("clear-btn").addEventListener("click", function () {

  if (
    confirm("This will clear everything in the To-Do list. \n \n Are you sure?")
  ) {
    localStorage.clear();
    document.getElementById("list").innerHTML = "";
  } else {
    return;
  }
});

// Linethrough on click - TODO - needs cleaning up big time
var element = document.getElementById("list-item");
var listElementArray = document.querySelectorAll("#list-item");

if (element) {
  var i;
  for (i = 0; i < listElementArray.length; i++) {
    element.style.textDecoration = "none";
  }
}

function strikeThroughOnClick() {
  element = document.getElementById("list-item");
  if (element.style.textDecoration === "none") {
    element.style.textDecoration = "line-through";
    console.log("I got here");
  } else {
    element.style.textDecoration = "none";
    console.log("I also got here");
  }
}

listElementArray.forEach(function (strikeText) {
  strikeText.addEventListener("click", function () {
    strikeThroughOnClick();
  });
});
